﻿// этот мод был написан MamaMonke прошу не воровать и не присваевать код/мод себе. Код будет выложен на гитхаб и только на гитхабе https://github.com/MamaMonke .
// этот мод/бот полностью бесплатный и open source. Если вы за него заплатили вас обманули. Заходи к нам в дискорд сервер https://discord.gg/8GE6gzagDg .
// мои соцсети
// tiktok.com/@mamamonkett
// youtube.com/@мамамонке
// github.com/MamaMonke

using BepInEx;
using GorillaLocomotion;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using Debug = UnityEngine.Debug;
using Random = UnityEngine.Random;

[BepInPlugin("com.mamamonke.monkebot", "Monke Bot", "1.2.0")]
public class VoiceBot : BaseUnityPlugin
{
    private GTPlayer player;
    private Vector3 targetPoint;
    private List<Vector3> waypoints;
    private int currentWaypointIndex = -1;
    private float lastSoundTime;
    private float soundInterval = 60f;
    private Dictionary<KeyCode, string> voiceBindings;
    private List<KeyCode> randomSoundKeys;

    // Система анти-застревания
    private Vector3 lastPosition;
    private float stuckTimer = 0f;
    private float stuckCheckInterval = 20f;
    private float minMovementDistance = 1.5f;

    // Отладка координат
    private float lastDebugTime = 0f;
    private float debugInterval = 5f;

    // Включение/выключение бота
    private bool botEnabled = true;

    // НАСТРОЙКА СКОРОСТИ
    private float movementSpeed = 1.5f;
    private float minSpeed = 0.1f;
    private float maxSpeed = 15.0f;

    // Импорт Windows функций для эмуляции нажатий
    [DllImport("user32.dll")]
    static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, uint dwExtraInfo);

    const int KEYEVENTF_KEYDOWN = 0x0000;
    const int KEYEVENTF_KEYUP = 0x0002;

    void Awake()
    {
        Debug.Log("MonkeBot загружен!");
        InitializeWaypoints();
        InitializeVoiceBindings();

        lastPosition = Vector3.zero;
    }

    void InitializeVoiceBindings()
    {
        // Тут либо Alpha123 либо KeyPad123. Название в "" должно быть таким же что и название звкука в войсмоде
        // Не забудьте забиндить звуки в войсмоде на клавиши которые вы указали ниже!

        voiceBindings = new Dictionary<KeyCode, string>
        {
            // Alpha клавиши (1-0)
            { KeyCode.Alpha1, "citata_ot_monkebota" },
            { KeyCode.Alpha2, "Joke1" },
            { KeyCode.Alpha3, "60_seconds_citata" },
            { KeyCode.Alpha4, "GhostReactor" },
            { KeyCode.Alpha5, "Creator_name" },
            { KeyCode.Alpha6, "Uncomming" },
            { KeyCode.Alpha7, "Credits" },
            { KeyCode.Alpha8, "cant_hear" },
            { KeyCode.Alpha9, "are_you_scared_lucy" },
            { KeyCode.Alpha0, "how_was_ur_day_and_reports" },
            
            // Кей пады не работают пока-что. Хз почему
            //{ KeyCode.Keypad0, "citata_ot_monkebota" },
            //{ KeyCode.Keypad1, "60_seconds_citata" },
            //{ KeyCode.Keypad2, "zvuk3" },
            //{ KeyCode.Keypad3, "zvuk4" },
            //{ KeyCode.Keypad4, "zvuk5" },
            //{ KeyCode.Keypad5, "zvuk6" },
            //{ KeyCode.Keypad6, "zvuk7" },
            //{ KeyCode.Keypad7, "zvuk8" },
            //{ KeyCode.Keypad8, "zvuk9" },
            //{ KeyCode.Keypad9, "zvuk10" }
            
            
        };

        // ФИЛЬТРАЦИЯ:ТОЛЬКО Alpha и KeyPad клавиши
        randomSoundKeys = new List<KeyCode>();
        foreach (var binding in voiceBindings)
        {
            // Проверяем что клавиша ТОЛЬКО Alpha ИЛИ KeyPad
            bool isAlpha = (binding.Key >= KeyCode.Alpha0 && binding.Key <= KeyCode.Alpha9);
            bool isKeypad = (binding.Key >= KeyCode.Keypad0 && binding.Key <= KeyCode.Keypad9);

            if (isAlpha || isKeypad)
            {
                randomSoundKeys.Add(binding.Key);
                Debug.Log("Добавлена разрешенная клавиша: " + binding.Key + " (Alpha: " + isAlpha + ", KeyPad: " + isKeypad + ")");
            }
            else
            {
                Debug.LogError("ЗАПРЕЩЕННАЯ КЛАВИША: " + binding.Key + " - удалена из списка!");
            }
        }

        Debug.Log("Загружено " + randomSoundKeys.Count + " звуков (ТОЛЬКО Alpha и KeyPad)");

        // Проверяем что KeyPad клавиши действительно добавлены
        int keypadCount = 0;
        foreach (var key in randomSoundKeys)
        {
            if (key >= KeyCode.Keypad0 && key <= KeyCode.Keypad9)
                keypadCount++;
        }
        Debug.Log("KeyPad клавиш в списке: " + keypadCount);
    }

    void InitializeWaypoints()
    {
        waypoints = new List<Vector3>
        {   // тут можно поменять куда идет бот.
            new Vector3(-27.618f, 2.5558f, -50.2303f),
            new Vector3(-28.3447f, 2.483f, -74.955f),
            new Vector3(-71.1524f, 2.2254f, -54.7567f),
            new Vector3(-47.7034f, 5.6362f, -42.823f)
        };

        Debug.Log("Координаты точек:");
        for (int i = 0; i < waypoints.Count; i++)
        {
            Debug.Log("  Точка " + (i + 1) + ": " + waypoints[i]);
        }

        SelectRandomWaypoint();
    }

    void Update()
    {
        if (player == null)
        {
            player = GTPlayer.Instance;
            if (player != null)
            {
                Debug.Log("Бот подключен к игроку!");
                lastPosition = player.transform.position;
            }
            return;
        }

        // Если бот выключен - не делаем ничего
        if (!botEnabled) return;

        // Отладка координат каждые 5 секунд
        if (Time.time - lastDebugTime > debugInterval)
        {
            DebugCoordinates();
            lastDebugTime = Time.time;
        }

        // Проверка на застревание
        CheckIfStuck();

        // Автоматическое проигрывание звуков
        if (Time.time - lastSoundTime > soundInterval)
        {
            PlayRandomVoiceSound();
            lastSoundTime = Time.time;
        }

        // Движение к цели
        Vector3 direction = (targetPoint - player.transform.position).normalized;
        float distanceToTarget = Vector3.Distance(player.transform.position, targetPoint);

        if (distanceToTarget > 0.5f)
        {
            player.transform.position = Vector3.MoveTowards(
                player.transform.position,
                targetPoint,
                movementSpeed * Time.deltaTime  // ИСПОЛЬЗУЕМ НАСТРАИВАЕМУЮ СКОРОСТЬ
            );

            // ПОВОРОТ БОТА В СТОРОНУ ДВИЖЕНИЯ
            if (direction != Vector3.zero)
            {
                Vector3 horizontalDirection = new Vector3(direction.x, 0, direction.z);
                if (horizontalDirection.magnitude > 0.1f)
                {
                    // Поворачиваем TurnParent по оси Y
                    RotateTurnParent(horizontalDirection);
                }
            }
        }
        else
        {
            Debug.Log("Достигнута точка " + (currentWaypointIndex + 1));
            SelectRandomWaypoint();
        }
    }

    // Метод для поворота тела в сторону в которую она идет
    void RotateTurnParent(Vector3 direction)
    {
        try
        {
            
            Transform turnParent = player.transform.Find("TurnParent");
            if (turnParent == null)
            {
                // Если не нашли напрямую, ищем в детях
                turnParent = FindDeepChild(player.transform, "TurnParent");
            }

            if (turnParent != null)
            {
                // Вычисляем угол поворота по направлению движения
                float targetAngle = Mathf.Atan2(direction.x, direction.z) * Mathf.Rad2Deg;

                // Плавный поворот по Y
                Quaternion targetRotation = Quaternion.Euler(0f, targetAngle, 0f);
                turnParent.rotation = Quaternion.Slerp(
                    turnParent.rotation,
                    targetRotation,
                    8f * Time.deltaTime
                );

                Debug.Log("Поворот тела на угол: " + targetAngle);
            }
            else
            {
                Debug.Log("Не найден TurnParent объект");
            }
        }
        catch (System.Exception e)
        {
            Debug.Log("Ошибка поворота TurnParent: " + e.Message);
        }
    }

    // Вспомогательный метод для поиска в глубину иерархии (только не угарайте с метода FindDeepChild пж)
    Transform FindDeepChild(Transform parent, string childName)
    {
        foreach (Transform child in parent)
        {
            if (child.name == childName)
                return child;

            Transform result = FindDeepChild(child, childName);
            if (result != null)
                return result;
        }
        return null;
    }

    void ToggleBot()
    {
        botEnabled = !botEnabled;
        if (botEnabled)
        {
            Debug.Log("Бот ВКЛЮЧЕН");
            // При включении сбрасываем таймеры
            lastSoundTime = Time.time;
            lastPosition = player.transform.position;
        }
        else
        {
            Debug.Log("Бот ВЫКЛЮЧЕН");
        }
    }

    void DebugCoordinates()
    {
        if (player == null) return;

        Vector3 currentPos = player.transform.position;
        float distanceToTarget = Vector3.Distance(currentPos, targetPoint);

        Debug.Log("ОТЛАДКА КООРДИНАТ:");
        Debug.Log("  Цель: " + targetPoint);
        Debug.Log("  Текущая позиция: " + currentPos);
        Debug.Log("  Расстояние до цели: " + distanceToTarget.ToString("F2") + "m");
        Debug.Log("  Статус бота: " + (botEnabled ? "ВКЛ" : "ВЫКЛ"));
        Debug.Log("  Скорость движения: " + movementSpeed.ToString("F1"));
    }

    void CheckIfStuck()
    {
        if (player == null) return;

        Vector3 currentPos = player.transform.position;
        Vector2 lastPosXZ = new Vector2(lastPosition.x, lastPosition.z);
        Vector2 currentPosXZ = new Vector2(currentPos.x, currentPos.z);

        float horizontalDistance = Vector2.Distance(lastPosXZ, currentPosXZ);

        stuckTimer += Time.deltaTime;

        if (stuckTimer >= stuckCheckInterval)
        {
            if (horizontalDistance < minMovementDistance)
            {
                Debug.Log("Бот застрял! Прошел только " + horizontalDistance.ToString("F1") + "m за " + stuckCheckInterval + "сек");
                TeleportToWaypoint(0);
            }

            stuckTimer = 0f;
            lastPosition = currentPos;
        }
    }

    void TeleportToWaypoint(int waypointIndex)
    {
        if (waypoints != null && waypointIndex >= 0 && waypointIndex < waypoints.Count)
        {
            player.transform.position = waypoints[waypointIndex];
            currentWaypointIndex = waypointIndex;
            targetPoint = waypoints[waypointIndex];

            Debug.Log("Телепортирован в точку " + (waypointIndex + 1) + ": " + waypoints[waypointIndex]);

            Invoke(nameof(SelectRandomWaypoint), 2f);
        }
    }

    void PlayRandomVoiceSound()
    {
        if (randomSoundKeys.Count == 0) return;

        // Выбираем случайную клавишу из ВСЕХ доступных (Alpha + KeyPad)
        KeyCode randomKey = randomSoundKeys[Random.Range(0, randomSoundKeys.Count)];
        string soundName = voiceBindings[randomKey];

        Debug.Log("Случайный выбор: " + soundName + " (клавиша " + randomKey + ")");

        PlayVoiceSound(randomKey);
    }

    void PlayVoiceSound(KeyCode key)
    {
        if (voiceBindings.ContainsKey(key))
        {
            string soundName = voiceBindings[key];
            Debug.Log("Пытаюсь воспроизвести звук: " + soundName + " через клавишу " + key);

            // ДОПОЛНИТЕЛЬНАЯ ПРОВЕРКА: убеждаемся что это ТОЛЬКО Alpha или KeyPad
            bool isAlpha = (key >= KeyCode.Alpha0 && key <= KeyCode.Alpha9);
            bool isKeypad = (key >= KeyCode.Keypad0 && key <= KeyCode.Keypad9);

            if (!isAlpha && !isKeypad)
            {
                Debug.LogError("ПОПЫТКА ИСПОЛЬЗОВАТЬ ЗАПРЕЩЕННУЮ КЛАВИШУ: " + key);
                return;
            }

            // Пробуем активацию Voicemod Намлок не у всех работает.
            bool success = TryActivateVoicemod(key);

            if (!success)
            {
                Debug.Log("Voicemod не сработал. Проверь:");
                Debug.Log("  1. Voicemod запущен");
                Debug.Log("  2. Горячие клавиши настроены в Voicemod");
                Debug.Log("  3. Num Lock включен для KeyPad клавиш");
            }
        }
    }

    bool TryActivateVoicemod(KeyCode key)
    {
        try
        {
            // Простая эмуляция клавиш
            SimulateKeyPress(key);
            return true;
        }
        catch (System.Exception e)
        {
            Debug.Log("Ошибка активации Voicemod: " + e.Message);
            return false;
        }
    }

    void SimulateKeyPress(KeyCode key)
    {
        try
        {
            byte keyCode = (byte)key;

            Debug.Log($"Эмуляция клавиши: {key} (код: {keyCode})");

            // Нажимаем клавишу
            keybd_event(keyCode, 0, KEYEVENTF_KEYDOWN, 0);

            // Ждем немного
            System.Threading.Thread.Sleep(100);

            // Отпускаем клавишу
            keybd_event(keyCode, 0, KEYEVENTF_KEYUP, 0);

            Debug.Log("Успешно эмулировано нажатие " + key);
        }
        catch (System.Exception e)
        {
            Debug.Log("Ошибка эмуляции клавиши " + key + ": " + e.Message);
        }
    }

    void SelectRandomWaypoint()
    {
        if (waypoints == null || waypoints.Count == 0) return;

        int newIndex;
        do
        {
            newIndex = Random.Range(0, waypoints.Count);
        }
        while (newIndex == currentWaypointIndex && waypoints.Count > 1);

        currentWaypointIndex = newIndex;
        targetPoint = waypoints[currentWaypointIndex];

        Debug.Log("Новая цель: Точка " + (currentWaypointIndex + 1) + " - " + targetPoint);
    }

    void OnGUI()
    {
        // Увеличиваем высоту окна для ползунка. НЕ МЕНЯТЬ ТЕКСТ В GUI.Box(new Rect(10, 10, 400, 500), "Monke Bot");
        GUI.Box(new Rect(10, 10, 400, 500), "Monke Bot");

        int yPos = 40;

        // Кнопка включения/выключения
        string toggleText = botEnabled ? "ВЫКЛЮЧИТЬ БОТА" : "ВКЛЮЧИТЬ БОТА";
        if (GUI.Button(new Rect(20, yPos, 360, 35), toggleText))
        {
            ToggleBot();
        }
        yPos += 45;

        if (GUI.Button(new Rect(20, yPos, 360, 35), "СЛЕДУЮЩАЯ ТОЧКА"))
        {
            SelectRandomWaypoint();
        }
        yPos += 45;

        if (GUI.Button(new Rect(20, yPos, 360, 35), "СЛУЧАЙНЫЙ ЗВУК"))
        {
            PlayRandomVoiceSound();
        }
        yPos += 45;

        // ПОЛЗУНОК СКОРОСТИ
        GUI.Label(new Rect(20, yPos, 150, 25), "СКОРОСТЬ: " + movementSpeed.ToString("F1"));
        yPos += 25;

        // Ползунок для изменения скорости
        movementSpeed = GUI.HorizontalSlider(new Rect(20, yPos, 360, 25), movementSpeed, minSpeed, maxSpeed);
        yPos += 35;

        // Кнопки быстрой настройки скорости
        if (GUI.Button(new Rect(20, yPos, 115, 25), "МЕДЛЕННО"))
        {
            movementSpeed = 0.8f;
        }
        if (GUI.Button(new Rect(145, yPos, 115, 25), "НОРМА"))
        {
            movementSpeed = 1.5f;
        }
        if (GUI.Button(new Rect(270, yPos, 110, 25), "БЫСТРО"))
        {
            movementSpeed = 3.0f;
        }
        yPos += 35;

        // Отладка координат
        if (GUI.Button(new Rect(20, yPos, 360, 35), "ОТЛАДКА КООРДИНАТ"))
        {
            DebugCoordinates();
        }
        yPos += 45;

        // Отображение привязок
        GUI.Label(new Rect(20, yPos, 360, 25), "ПРИВЯЗКИ Voicemod (ТОЛЬКО Alpha/KeyPad):");
        yPos += 30;

        foreach (var binding in voiceBindings)
        {
            GUI.Label(new Rect(20, yPos, 360, 25), "  " + binding.Key + " - " + binding.Value);
            yPos += 25;
        }

        yPos += 10;
        GUI.Label(new Rect(20, yPos, 360, 25), "АНТИ-ЗАСТРЕВАНИЕ: " + (stuckCheckInterval - stuckTimer).ToString("F0") + "с");
        yPos += 30;

        if (GUI.Button(new Rect(20, yPos, 360, 30), "ТЕЛЕПОРТ В ТОЧКУ 1"))
        {
            TeleportToWaypoint(0);
        }
        yPos += 35;

        // Информация
        GUI.Label(new Rect(20, yPos, 360, 25), "ЦЕЛЬ: Точка " + (currentWaypointIndex + 1));
        yPos += 25;
        GUI.Label(new Rect(20, yPos, 360, 25), "СКОРОСТЬ: " + movementSpeed.ToString("F1") + " ед/сек");
        yPos += 25;
        GUI.Label(new Rect(20, yPos, 360, 25), "СЛЕДУЮЩИЙ ЗВУК: " + (soundInterval - (Time.time - lastSoundTime)).ToString("F0") + "с");
        yPos += 25;
        GUI.Label(new Rect(20, yPos, 360, 25), "СТАТУС: " + (botEnabled ? "ВКЛ" : "ВЫКЛ"));
    }

    void SetSpecificWaypoint(int index)
    {
        if (waypoints != null && index >= 0 && index < waypoints.Count)
        {
            currentWaypointIndex = index;
            targetPoint = waypoints[index];
        }
    }
}

// Надеюсь вам понравится мой бот.
// Для компиляции кода вам нужно добавить ссылки на асембли, бепинекс, UnityEngine, UnityEngine.AudioModule, UnityEngine.CoreModule, UnityEngine.IMGUIModule, UnityEngine.InputLegacyModule, UnityEngine.PhysicsModule, UnityEngine.UnityWebRequestAudioModule и последнее UnityEngine.UnityWebRequestModule